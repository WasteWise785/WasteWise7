# WasteWise 🌱 — Give Every Object a Second Life

A mobile-friendly, static HTML/CSS/JavaScript Progressive Web App for creative reuse. No account, paid API, database, or AI service is required.

## Files
- `index.html` — app screens and privacy/safety information
- `styles.css` — responsive mobile-first design
- `app.js` — idea library, photo preview, challenges, badges, points, and local storage
- `manifest.webmanifest` — install metadata
- `sw.js` — app-shell caching and offline fallback
- `offline.html` — fallback page
- `icons/` — 192 px and 512 px PNG icons

## Test locally
A PWA requires HTTPS or localhost; opening `index.html` directly from the file manager will not enable installation or service-worker caching. You can still inspect the page, but use a hosted HTTPS URL for full testing.

## Publish free using GitHub Pages (phone-friendly)
1. Open `https://github.com` in your Android browser and sign in or create an account with adult help if needed.
2. Create a new **public** repository named `wastewise` (or another name you choose).
3. Upload all files and the `icons` folder from this ZIP. Keep the folder structure unchanged. Use the repository's **Add file → Upload files** option; on mobile, you may need your browser's desktop-site option.
4. Open repository **Settings → Pages**. Under build/deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish. The site URL normally looks like `https://YOUR-USERNAME.github.io/wastewise/`. Use the exact URL GitHub Pages displays.
6. Open that HTTPS URL in Chrome on Android. Browse the app once while online so its files can be cached.
7. In Chrome, open the ⋮ menu and choose **Install app** or **Add to Home screen** (wording depends on browser/device). If an in-app install button appears, you can try it too.

## Important
- A PWA is a website that can be installed from a supported browser; it is not a native Android APK and this does not publish it on Google Play.
- Publishing a native Play Store app requires a separate Android packaging and Play Console process. Ask a parent/guardian to help with accounts and any current age or publishing requirements.
- Keep repository content public only if you are comfortable with anyone viewing the source code. This app contains no secrets or API keys.
- Photos are only previewed in the browser and are not sent to a server.
- Progress uses `localStorage` and is browser/device-specific; it does not automatically sync. Clearing site data can remove progress.
- Waste rules vary by location. For batteries, e-waste, chemicals, and broken glass, consult your municipality or an authorised collection point. Never dismantle electronics or handle unsafe waste.
